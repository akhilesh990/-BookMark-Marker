// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/// Example Valid URLs: https://learning.ccbp.in/, https://www.google.com/

let bookmarkFormEl = document.getElementById("bookmarkForm");
bookmarkFormEl.addEventListener("submit", function(event) {
    event.preventDefault();
});

let formData = {
    id: 1,
    name: "",
    url: ""
};

let siteNameInputEl = document.getElementById("siteNameInput");
let siteUrlInputEl = document.getElementById("siteUrlInput");

let submitBtnEl = document.getElementById("submitBtn");

let siteNameErrMsgEl = document.getElementById("siteNameErrMsg");
let siteUrlErrMsgEl = document.getElementById("siteUrlErrMsg");





siteNameInputEl.addEventListener("change", function(event) {
    formData.name = event.target.value;
});

function createAndAppend(name, url) {
    let bookmarksListEl = document.getElementById("bookmarksList");

    let listContainer = document.createElement("li");
    listContainer.classList.add("result-container");
    bookmarksListEl.appendChild(listContainer);

    let listHeading = document.createElement("h1");
    listHeading.textContent = name;
    listHeading.classList.add("list-heading");
    listContainer.appendChild(listHeading);

    let breakEl = document.createElement("br");
    listContainer.appendChild(breakEl);

    let listAnchor = document.createElement("a");
    listAnchor.href = url;
    listAnchor.target = "_blank";
    listAnchor.textContent = url;
    listContainer.appendChild(listAnchor);
}

submitBtnEl.addEventListener("click", function(event) {
    event.preventDefault();
    if (siteNameInputEl.value === "" && siteUrlInputEl.value === "") {
        siteNameErrMsgEl.textContent = "Required*";
        siteUrlErrMsgEl.textContent = "Required*";
    } else if (siteNameInputEl.value === "") {
        siteNameErrMsgEl.textContent = "Required*";
        siteUrlErrMsgEl.textContent = "";
    } else if (siteUrlInputEl.value === "") {
        siteNameErrMsgEl.textContent = "";
        siteUrlErrMsgEl.textContent = "Required*";
    } else {
        siteNameErrMsgEl.textContent = "";
        siteUrlErrMsgEl.textContent = "";
        let siteNameInputVal = siteNameInputEl.value;
        let siteUrlInputVal = siteUrlInputEl.value;
        formData.name = siteNameInputVal;
        formData.url = siteUrlInputVal;

        createAndAppend(formData.name, formData.url);
    }

});